import java.util.Scanner;

public class Assignment3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Employee's Full Name: ");
		String name = sc.nextLine();
		System.out.println("Enter the number weekly work hours: ");
		int hoursWorked = sc.nextInt();
		System.out.println("Enter the hourly pay: ");
		double pay = sc.nextDouble();
		System.out.println("Enter the Federal Tax rate as a decimal (20% is .2): ");
		double fedTax = sc.nextDouble();
		System.out.println("Enter the state tax rate as a decimal (9% is .09): ");
		double stateTax = sc.nextDouble();

		double grossPay = pay * hoursWorked;
		double fedTaxWithholding = grossPay * fedTax;
		double stateTaxWithholding = grossPay * stateTax;
		double totalDeduction = fedTaxWithholding + stateTaxWithholding;
		double netPay = grossPay - totalDeduction;

		String[] lineSplit = name.split(",");
		String[] newName = lineSplit[0].split(" ");
		String newLine = newName[2] + "," + newName[0] + "," + newName[1];

		System.out.println("Employee Name: " + newLine);
		System.out.println("Number of Hours Worked Weekly: " + hoursWorked);
		System.out.println("Hourly Pay Rate: " + pay);
		System.out.println("Gross Pay: " + grossPay);
		System.out.println("Deductions: ");
		System.out.println("Federal Witholding (20%): " + fedTaxWithholding);
		System.out.println("State Withholding: " + (Math.round(stateTaxWithholding * 100.0) / 100.0));
		System.out.println("Total Deduction: " + (Math.round(totalDeduction * 100.0) / 100.0));
		System.out.println("Net Pay: " + Math.round(netPay * 100.0) / 100.0);

	}

}
